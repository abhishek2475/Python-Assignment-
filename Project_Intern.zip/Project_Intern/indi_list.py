#importing pandas
import pandas as pd

# defining, reading a CSV file
def creatingCSV(Dpath , Name):
    read_file = pd.read_excel(Dpath)
    df = read_file.to_csv(Name ,index=None)
    df = pd.read_csv(Name)
    return df

#working with csv file now
#converting my .xlsx file to .csv
dUID = creatingCSV("Book1.xlsx" , "UserId.csv")
df = creatingCSV("Book2.xlsx" , "Datas.csv")
rank=[]
# for adding a rank column
for i in df["S No"] :
    rank.append(i)
#Sorting the table in descending order of 'total_statements'
df = df.sort_values(by= 'total_statements', ascending=False)
df = df.drop(['S No'] , axis=1)
df.insert(0,'Rank', rank )
#exporting the result to a .csv file
df.to_csv("Leaderboard_Individual(Output).csv" , index=False)
# Now I first sorted the First Table
dUID = dUID.sort_values(by= 'Team Name', ascending=False)
#making a dictionary 
d1 = dict()
d2 = dict()
final = []
#assigning values to the dictionary
for i in range(21):
    if dUID["Team Name"][i] not in d1:
        d1[dUID["Team Name"][i]] = [dUID["Name"][i]]
    else:
        d1[dUID["Team Name"][i]].append(dUID["Name"][i])
    d2[df["name"][i]] = [df["total_statements"][i],df["total_reasons"][i]]
# calculating average for statement and resons and then storing the total sum of the average statement and average reason
for i in d1:
    s = [d2[x][0] for x in d1[i]]
    avg_statements = float("{:.2f}".format(sum(s)/len(s)))
    r = [d2[x][1] for x in d1[i]]
    avg_reasons = float("{:.2f}".format(sum(r)/len(r)))
    sum1 = float(avg_statements)+float(avg_reasons)
    final.append([i,avg_statements,avg_reasons,sum1])
#making a new dataframe 
table = pd.DataFrame(final,columns=["Team Name","Average Statements","Average Reasons","sum"])
#Finally sorting the table by descending order of sum
table = table.sort_values(by= 'sum', ascending=False)
#dropping the column sum as it is not needed in the output
table = table.drop(['sum'] , axis=1)
table.insert(0,'Rank', rank[:8])
table.to_csv("Leaderboard_TeamWise(Output).csv" , index=False)